# In the routine below, you should draw your initials in perspective

from matlib import *
from drawlib import *

def persp_initials():
    pass
