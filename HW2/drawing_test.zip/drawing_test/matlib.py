# Matrix Stack Library -- Use your code from Project 1A

def gtInitialize():
    pass

def gtPushMatrix():
    pass

def gtPopMatrix():
    pass

def gtTranslate(x, y, z):
    pass

def gtScale(x, y, z):
    pass

def gtRotateX(theta):
    pass

def gtRotateY(theta):
    pass

def gtRotateZ(theta):
    pass
