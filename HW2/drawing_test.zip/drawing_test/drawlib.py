# Drawing Routines, like OpenGL

from matlib import *

def gtOrtho(left, right, bottom, top, near, far):
    pass

def gtPerspective(fov, near, far):
    pass

def gtBeginShape():
    pass

def gtEndShape():
    pass

def gtVertex(x, y, z):
    pass
