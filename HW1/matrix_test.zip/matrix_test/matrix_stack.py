# Matrix Stack Library

# you should modify the routines below to complete the assignment

def gtInitialize():
    pass

def gtPushMatrix():
    pass

def gtPopMatrix():
    pass

def gtTranslate(x, y, z):
    pass

def gtScale(x, y, z):
    pass

def gtRotateX(theta):
    pass

def gtRotateY(theta):
    pass

def gtRotateZ(theta):
    pass

def gtGetMatrix():
    pass

def print_ctm():
    pass   
